<html>

<head>

    <title>Plane Management</title>
    <link rel="stylesheet" href="plane.css"  type="text/css">
</head>
    
    
    <body>
    
     <div class="banner">
         
         Plane management
        
        
    </div>
        
        <div class="panel">
            
            <a href="all_plane_infoo_plane.php">
                <div class="a">
                
                All Plane info
            
            </div>
            
            </a>
            
            
          <a href="insert_plane.php">  <div class="b">
                
                add new plane
            
              </div></a>
              
              
              
           <a href="delete_plane.php"> <div class="c">
                
                Delete a plane
            
            </div></a>
            
            <a href="update.php"><div class="d">
                
                update plane info
            
            </div></a>
            
            <a href="#"><div class="e">
                
                plane and its crew
                
            
            </div></a>
            
            <a href="#"><div class="f">
                
                create database
                
            
            </div></a>
        
        
        </div>
        
        
        <div class="footer">
            
            Copyright &copy 2017
        
        </div>
    
    </body>

</html>