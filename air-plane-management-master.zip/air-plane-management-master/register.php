<html>

    <head>
    
        <title>Registration form</title>
        <link rel="stylesheet" type="text/css" href="register.css">
        
        
    </head>
    
    <body>
        
        <div class="main">
            
            <div class="banner">
            
            <span class="text">welcome to bangladesh airways</span> 
        
        </div>
        
        <div class="registration_form">
            
            <div class="reg">
        
             <div class="text"> fill up this form pls</div>
            
            
            <form class="form" method="post" action="reg.php">
                
                user name: <input  name="name1" type="text" required >
                <br>
            
                Fast name:<input name="name2" type="text" required >
                <br>
                Last name:<input  name="name3" type="text" required >
                <br>
                
                mobile num: <input  name="name4" type="text" required >
                <br>
                
                city: <input  name="name5" type="text"  required>
                <br>
                
                house num : <input  name="name6" type="text" required >
                <br>
                
                permanent address: <input  name="name7" type="text" required >
                 
                <br>

              Gender:
                 <input type="radio"  name="gender" value="male"  required>male

                <input type="radio"  name="gender" value="female" required>Female

                <br>
                password: <input  name="name8" type="password" required>
                <br>


                <input class="name9" type="submit" value="Submit">
                
                
                
                
            
            </form>
            
            
            
        
        
        </div>
            
        </div>    
        
        
        
        </div>
    
    
    
    </body>




</html>