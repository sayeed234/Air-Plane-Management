<html>

    <head>
    <title>Admin Panel</title>
        <link rel="stylesheet" href="admin.css" type="text/css">
    
    </head>
    
    <body>
    
    <div class="admin_panel">
        
        <div class="banner">
            
        Admin panel
        
        </div>
        
        <div class="panel">
            
        <a  href="plane.php">   <div class="a">
                
                plane management
            
            </div></a>
            
        <a href="#">  <div class="b">
                
                crew management
            
            </div></a>  
            
          <a href="#">  <div class="c">
                
                booking management
            </div> </a>
 <a href="dis_reg.php">  <div class="d">
                
               regestation details
            
            </div></a>  
        
        
        
        </div>
        
        <div class="footer">
        
        </div>
        
    </div>
    
    
    </body>



</html>